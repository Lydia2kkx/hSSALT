install.packages("tinytex")
tinytex::install_tinytex()

tinytex::is_tinytex()  

Sys.which("pdflatex")

tinytex::tinytex_root()

Sys.getenv("PATH")

Sys.setenv(PATH = paste(
  "C:/Users/avner/AppData/Roaming/TinyTeX/bin/windows",
  Sys.getenv("PATH"),
  sep = ";"
))
Sys.which("pdflatex")


bin <- "C:/Users/avner/AppData/Roaming/TinyTeX/bin/windows"
Sys.setenv(PATH = paste(bin, Sys.getenv("PATH"), sep = ";"))
Sys.which("pdflatex")    # should now show the exe path

tools::Rd2pdf(pkg = ".", output = "hSSALT.pdf")

load("testing1.Rdata")