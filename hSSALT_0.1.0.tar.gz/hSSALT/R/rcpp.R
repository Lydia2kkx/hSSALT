#' @useDynLib hSSALT, .registration = TRUE
#' @importFrom Rcpp evalCpp
#' @importFrom stats qnorm pnorm uniroot quantile pbinom dexp pexp dgeom pgeom rexp rbinom runif na.omit
NULL