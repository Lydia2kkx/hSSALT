# hSSALT
hSSALT Rpackage: simple heterogeneous SSALT with exponential life distribution based on CE assumption
