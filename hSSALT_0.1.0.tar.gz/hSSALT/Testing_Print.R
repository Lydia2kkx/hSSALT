# constructor (optional)
CIhSSALT <- function(theta1, theta21, theta22, p, B, j, alpha, type) {
  structure(
    list(theta1 = theta1, theta21 = theta21, theta22 = theta22, p = p,
         B = B, j = j, alpha = alpha, type="Percentile"),
    class = "CIhSSALT"
  )
}

# print method
print.CIhSSALT <- function(x, ...) {
  
  title <- sprintf("%s confidence intervals for theta1, theta21, theta22 and p", x$type)
  
  # Help functions
  number_formatting <- function(z, dig=7) formatC(z, digits = dig, format = "g", drop0trailing = FALSE)
  separation_line <- paste(rep("-", 50), collapse = "")
  
  # Print
  cat(title, "\n", sep = "")
  cat(sprintf("Significance level: alpha = %s\n", number_formatting(x$alpha, dig=3)))
  cat(sprintf("Valid bootstrap replications: B = %s\n", x$B))
  cat(sprintf("Total bootstrap replications: j = %s\n", x$j))
  
  cat("\n", separation_line, "\n", sep = "")
  
  cat(sprintf("theta1  (%s, %s)\n",  number_formatting(x$theta1[1]),  number_formatting(x$theta1[2])))
  cat(sprintf("theta21 (%s, %s)\n", number_formatting(x$theta21[1]), number_formatting(x$theta21[2])))
  cat(sprintf("theta22 (%s, %s)\n", number_formatting(x$theta22[1]), number_formatting(x$theta22[2])))
  cat(sprintf("p       (%s, %s)\n", number_formatting(x$p[1]), number_formatting(x$p[2])))
  
  # To be able to capture list in variable with print
  invisible(x)
}


res <- CIhSSALT(
  theta1  = c(15.63104, 61.44967),
  theta21 = c(0.021924, 1.546610),
  theta22 = c(3.243080, 14.39131),
  p       = c(0.055219, 0.558031),
  B = 1000, j = 1081, alpha = 0.05
)

res  # or print(res)
